import pygame, sys, os
from pygame.locals import *
import requests, time, threading
from collections import deque
from queue import Queue

# ===========================================
#  THREADED PHYPHOX STREAM
# ===========================================
def phypox_worker(url, out_queue, poll_interval=0.05):
    """Continuously poll Phyphox sensor data in background."""
    while True:
        try:
            response = requests.get(url, timeout=0.5)
            data = response.json()
            x = data['buffer']['accX']['buffer'][0]
            y = data['buffer']['accY']['buffer'][0]
            out_queue.put((x, y))
        except Exception as e:
            print("Error reading Phyphox:", e)
            out_queue.put((0, 0))
        time.sleep(poll_interval)


def get_latest(queue, default=(0, 0)):
    """Return the latest accelerometer values (discard old ones)."""
    value = default
    while not queue.empty():
        value = queue.get_nowait()
    return value


# ===========================================
#  SOKOBAN CLASS (your full class unchanged)
# ===========================================
# Paste your full Sokoban class here as-is
# (everything from class Sokoban: ... until the end of that class)
# ===========================================


# ===========================================
#  MAIN GAME LOOP
# ===========================================
def main():
    pygame.init()
    screen = pygame.display.set_mode((400, 300))
    skinfilename = os.path.join('borgar.png')

    try:
        skin = pygame.image.load(skinfilename)
    except (pygame.error, msg):
        print('cannot load skin')
        raise SystemExit(msg)
    skin = skin.convert()

    pygame.display.set_caption('sokoban.py')
    skb = Sokoban()
    skb.draw(screen, skin)
    clock = pygame.time.Clock()
    pygame.key.set_repeat(200, 50)

    # -----------------------------
    # Start threaded Phyphox reader
    # -----------------------------
    url = "http://10.143.194.122:8080/get?accX&accY"
    accel_queue = Queue()
    thread = threading.Thread(target=phypox_worker, args=(url, accel_queue), daemon=True)
    thread.start()

    # Motion smoothing and timing
    x_prev, y_prev = 0, 0
    alpha = 0.2
    last_move_time = 0
    cooldown = 0.01

    # -----------------------------
    # Game Loop
    # -----------------------------
    while True:
        clock.tick(60)

        if skb.auto == 0:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN:
                    if event.key == K_LEFT:
                        skb.move('l')
                    elif event.key == K_UP:
                        skb.move('u')
                    elif event.key == K_RIGHT:
                        skb.move('r')
                    elif event.key == K_DOWN:
                        skb.move('d')
                    elif event.key == K_BACKSPACE:
                        skb.undo()
                    elif event.key == K_SPACE:
                        skb.redo()
                    skb.draw(screen, skin)

                elif event.type == MOUSEBUTTONUP and event.button == 1:
                    mousex, mousey = event.pos
                    mousex //= (skin.get_width() / 4)
                    mousey //= (skin.get_width() / 4)
                    skb.mouse(mousex, mousey)

            # ---- Accelerometer-based movement ----
            x_accel, y_accel = get_latest(accel_queue)
            x_smooth = alpha * x_accel + (1 - alpha) * x_prev
            y_smooth = alpha * y_accel + (1 - alpha) * y_prev
            x_prev, y_prev = x_smooth, y_smooth

            current_time = time.time()
            if current_time - last_move_time > cooldown:
                if x_accel < -1:
                    skb.move('l')
                    last_move_time = current_time
                elif x_accel > 1:
                    skb.move('r')
                    last_move_time = current_time

                if y_accel < 1:
                    skb.move('u')
                    last_move_time = current_time
                elif y_accel > -1:
                    skb.move('d')
                    last_move_time = current_time

                skb.draw(screen, skin)
        else:
            skb.automove()
            skb.draw(screen, skin)

        pygame.display.update()
        pygame.display.set_caption(f"{len(skb.solution)}/{skb.push} - sokoban.py")


if __name__ == '__main__':
    main()
